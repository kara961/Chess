
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","autoloader()"],["c","Bishop"],["c","Board"],["c","Color"],["c","History"],["c","King"],["c","Knight"],["c","Log"],["c","Pawn"],["c","Piece"],["c","Position"],["c","Queen"],["c","Rook"]];
